//
//  TimeTransfer.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/5/8.
//  Copyright © 2018年 Echo. All rights reserved.
//

import Foundation
//一个处理时间表达的格式转换的类，提供的均为静态方法，可在其他类里不创建实例直接调用
class TimeTransfer {
    
    static func transTimeS(time: Date) -> String { //输入一个Date类数据，返回一个 “年 月 日 小时 分钟“ 的String
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
        let convertedDate = dateFormatter.string(from: time)
        return convertedDate
    }
    
    static func transTimeS2(time: Date) -> String { //输入一个Date类数据，返回一个 “年-月-日” 格式的string
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let convertedDate = dateFormatter.string(from: time)
        return convertedDate
    }
    
    static func transTimeI(time: Date) -> Int{ //输入一个Date类对象，返回一个 “时间戳” int值
        let timeInterval:TimeInterval = time.timeIntervalSince1970
        let timeStamp = Int(timeInterval)
        return timeStamp
    }
    
    static func transTimeST(time: String) -> Date { //输入一个String类对象，根据“年月日小时分钟”的格式生成一个对应的Date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
        return dateFormatter.date(from: time)! as Date
    }
    
    static func transTimeIT(time: Int) -> Date { //输入一个“时间戳”格式的int，返回一个相应的Date
        let timeInterval:TimeInterval = TimeInterval(time)
        let date = Date(timeIntervalSince1970: timeInterval)
        return date as Date
    }
}
