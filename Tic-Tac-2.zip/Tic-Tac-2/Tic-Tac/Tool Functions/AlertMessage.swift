//
//  AlertMessage.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/5/8.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit

class AlertMessage {
    static func alertOnlyConfirm(viewController : UIViewController, title : String, message : String){
        let alertController:UIAlertController=UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default))
        viewController.present(alertController, animated: true, completion: nil)
    }
}

