//
//  LongtermDetailsViewController.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/5/9.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import os.log

class LongtermDetailsViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up views if editing an existing Meal.
        if let longterm = longterm {
            navigationItem.title = longterm.name
            nameLabel.text   = longterm.name

            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
}
    //MARK: Preperties
    var longterm:Longterms?
    @IBOutlet weak var nameLabel: UILabel!
    
}
