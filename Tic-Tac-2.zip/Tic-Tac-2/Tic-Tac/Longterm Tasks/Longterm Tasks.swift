//
//  Longterm Tasks.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/5/9.
//  Copyright © 2018年 Echo. All rights reserved.
//

import Foundation
import CoreData

class Longterms: NSManagedObject{
    //Zhang: this class define object which is the type of "Long Term Task"
    static let entityName = "Longterms"
    @NSManaged var id : NSNumber!
    @NSManaged var name : String!
    @NSManaged var overview : String?
    @NSManaged var startTime : Date?
    @NSManaged var endTime : Date?
    @NSManaged var estimatedTime : NSNumber? //秒数 这里应该是NSNumber，暂时写成Date 会改
    @NSManaged var timeSoFar : NSNumber? //一个时间戳减去另一个时间戳，秒数
    @NSManaged var settingTime : Date?
    var done : Bool!
    var hasDDL : Bool! //distinct taks with dll and those without ddl
}
