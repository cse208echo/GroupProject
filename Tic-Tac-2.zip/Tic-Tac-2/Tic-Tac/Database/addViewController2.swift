//
//  addViewController2.swift
//  Tic-Tac
//
//  Created by mac on 2018/4/1.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import CoreData

class addViewController2: UIViewController{
    @IBOutlet weak var MemoEntry: UITextView!
    var TODO : ToDos?
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBOutlet weak var TimePicker: UIDatePicker!
    
    
    
    @IBAction func ConfirmBtn(_ sender: UIButton) {
        
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        
        if (MemoEntry.text! != ""){
                let _ = ToDosDAO.addWithPeriod(memo: MemoEntry.text!, period: Int(TimePicker.countDownDuration) )
                ToDosDAO.saveChanges()
        }else{
            let alertController:UIAlertController=UIAlertController(title: "You need to choose basic informations!", message: "", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default))
            self.present(alertController, animated: true, completion: nil)
        }
    }
}
