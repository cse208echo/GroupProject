//
//  TimelineViewController.swift
//  Tic-Tac
//
//  Created by Liu Juntong on 2018/5/6.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import CoreData

class TimelineViewController: UITableViewController {
    var items: [ToDos]
    var dele : AppDelegate
    var context : NSManagedObjectContext
    var ToDosDAO : ToDoDAO
    var indexPaths : [IndexPath]
    required init?(coder aDecoder: NSCoder) {
        dele = (UIApplication.shared.delegate as! AppDelegate)
        context = dele.persistentContainer.viewContext
        ToDosDAO = ToDoDAO(context: context)
        let missions = ToDosDAO.getTodayToDos()
        items = missions.allValues as! [ToDos]
        indexPaths = []
        let newRowIndex = items.count
        if !(newRowIndex==0) {
            for i in 0...newRowIndex{
                indexPaths = [IndexPath(row: i, section: 0)]
            }
        }
        
        super.init(coder: aDecoder)
}
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = tableView.indexPathForSelectedRow
        let item = items[(indexPath?.row)!]
            if let TDVC = segue.destination as? ToDoViewController{
                TDVC.ID = item.id as! Int
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.separatorStyle = UITableViewCellSeparatorStyle.none
        //这个part里面所有的代码都是做测试用的测试用例，正式程序里面不是这样的。
        /*let dele = (UIApplication.shared.delegate as! AppDelegate)
         let context = dele.persistentContainer.viewContext
         let ToDosDAO = ToDoDAO(context: context)
         //ToDosDAO.deletByID(Id: 10225)
         let users = ToDosDAO.getAll()*/
         for i in items{
         //print("i:\(i.memo! as String),\(i.beginTime! as Date),\(i.endTime! as Date),\(i.priority as! Int),\(i.id as! Int),\(i.flag )")
         print("i:\(i.memo! as String),\(i.period as! Int ),\(i.id as! Int),\(i.flag)")
         //ForTest.insertText("i:\(i.id as! Int), \(i.memo! as String)\n")
         }
         //let missions = ToDosDAO.getTodayToDos()
         //let T = missions.allKeys
         //print(T)
         //ToDosDAO.finishToDo(ID: 1522833231)
        //let ToDoDic = ToDosDAO.organizedByDay()
        //print(ToDoDic)
        //let TDTC = ToDoTimeCounter.init()
        
        //print(TDTC.TimeCounter(beginTime: users[1].beginTime!, endTime: users[1].endTime!))
        //print(TDTC.SuitableTimeCounter())
        //print("Today ToDos: \(ToDosDAO.getTodayToDos())")
        readDataAndAdd()
        
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
}
    func readDataAndAdd(){
        if !(indexPaths.endIndex==0) {
            for i in indexPaths{
                tableView.insertRows(at: [i], with: .top)
            }
        }
    }
    
    func configureCheckmark(for cell: UITableViewCell,with item: ToDos) {
        if item.flag{
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
    }
    
    var TextView: UITextView!
    
    func configureText(for cell: UITableViewCell,with item: ToDos) {
        TextView = cell.viewWithTag(1000) as! UITextView
        TextView.text = item.memo
    }
    
    
    // MARK:- TableView Delegates
    override func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var newHeight = tableView.rowHeight
        newHeight = CGFloat(100)
        return newHeight
    }
    
    override func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Todo", for: indexPath)
        let item = items[indexPath.row]
        configureText(for: cell, with: item )
        configureCheckmark(for: cell, with: item )
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
        if tableView.cellForRow(at: indexPath) != nil {
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }
    
    
    override func tableView(_ tableView: UITableView,commit editingStyle: UITableViewCellEditingStyle,forRowAt indexPath: IndexPath){
        let item = items[indexPath.row]
        let id = item.id
        ToDosDAO.deletByID(Id: id as! Int)
        items.remove(at: indexPath.row)
        let indexPaths = [indexPath]
        tableView.deleteRows(at: indexPaths, with: .automatic)
}
    
}
