//
//  LongtermTableViewController.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/5/14.
//  Copyright © 2018年 Echo. All rights reserved.
//


import UIKit
import os.log

class LongtermTableViewController: UITableViewController {
    
    //MARK:Properties
    
    var longterms : [Longterms]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let longtermDAO = LongtermDAO(context: context)
        longterms = longtermDAO.getAll()
        // Use the edit button item provided by the table view controller.
        navigationItem.leftBarButtonItem = editButtonItem
    }
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if longterms == nil {
            return 0
        }else{
            return longterms!.count
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifer = "LongtermTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifer, for: indexPath) as? LongtermTableViewCell else {
            fatalError("The dequeued cell is not an instance of LongtermTableViewCell")
        }
        let longterm = longterms![indexPath.row]
        
        cell.progress.progress = 0.5
        cell.nameLabel.text = longterm.name
        cell.IDLabel.text = "50%"
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            let dele = (UIApplication.shared.delegate as! AppDelegate)
            let context = dele.persistentContainer.viewContext
            let longtermDAO = LongtermDAO(context: context)
            let index = longterms![indexPath.row].id.intValue
            longtermDAO.deletByID(id: index)
            longterms!.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        super.prepare(for: segue, sender: sender)
        
        switch(segue.identifier ?? "") {
            
        case "AddLongterm":
            os_log("Adding a new longterm.", log: OSLog.default, type: .debug)
            
        case "ShowDetails":
            guard let longtermDetailViewController = segue.destination as? LongtermDetailsViewController else {
                fatalError("Unexpected destination: \(segue.destination)")
            }
            
            guard let selectedLongtermCell = sender as? LongtermTableViewCell else {
                fatalError("Unexpected sender: \(sender)")
            }
            
            guard let indexPath = tableView.indexPath(for: selectedLongtermCell) else {
                fatalError("The selected cell is not being displayed by the table")
            }
            
            let selectedLongterm = longterms![indexPath.row]
            longtermDetailViewController.longterm = selectedLongterm
            
        default:
            fatalError("Unexpected Segue Identifier; \(segue.identifier)")
        }
    }
    
    //MARK: Actions
    @IBAction func unwindTOLongtermList(sender : UIStoryboardSegue){
        if let sourceViewController = sender.source as? NewLongtermViewController, let longterm = sourceViewController.longterm {
            
            // Add a new meal.
            let newIndexPath = IndexPath(row: longterms!.count, section: 0)
            
            longterms!.append(longterm)
            tableView.insertRows(at: [newIndexPath], with: .automatic)
        }
    }
}
