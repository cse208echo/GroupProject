//
//  LongtermTableViewCell.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/5/14.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit

class LongtermTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var IDLabel: UILabel!
    @IBOutlet weak var progress: UIProgressView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

