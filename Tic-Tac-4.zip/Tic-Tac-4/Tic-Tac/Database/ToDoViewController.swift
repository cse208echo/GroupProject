//
//  ToDoViewController.swift
//  Tic-Tac
//
//  Created by Liu Juntongon 5/7/18.
//  Copyright © 2018 Echo. All rights reserved.
//

import UIKit

class ToDoViewController: UIViewController {
    var ID = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        let Task = ToDosDAO.getByID(ID: ID)
        Memo.insertText(Task.memo!)
        BeginTimeLabel.text = transTimeS(time: Task.beginTime!)
        EndTimeLabel.text = transTimeS(time: Task.endTime!)
        Memo.isEditable = false
        // Do any additional setup after loading the view.
    }
    
    func transTimeS(time: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let convertedDate = dateFormatter.string(from: time)
        return convertedDate
    }
    
    func transTimeST(time: String) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return dateFormatter.date(from: time)!
    }

    @IBOutlet weak var EndTimeLabel: UILabel!
    @IBAction func EndTimeButton(_ sender: UIButton) {
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        let Task = ToDosDAO.getByID(ID: ID)
        if !Task.flag {
            let alertController:UIAlertController=UIAlertController(title: "\n\n\n\n\n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
            let datePicker = UIDatePicker( )
            datePicker.datePickerMode = UIDatePickerMode.dateAndTime
            datePicker.date = NSDate() as Date
            alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default){
                (alertAction)in
                let alertController2:UIAlertController=UIAlertController(title: "You need to choose basic informations!", message: "", preferredStyle: UIAlertControllerStyle.alert)
                alertController2.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default){
                    (alertAction) in
                    let dele = (UIApplication.shared.delegate as! AppDelegate)
                    let context = dele.persistentContainer.viewContext
                    let ToDosDAO = ToDoDAO(context: context)
                    self.EndTimeLabel.text = self.transTimeS(time: datePicker.date)
                    ToDosDAO.deletByID(Id: self.ID)
                    ToDosDAO.addWithTime(memo: self.Memo.text, beginTime: self.transTimeST(time: self.BeginTimeLabel.text!), endTime: datePicker.date)
                    
                })
                alertController2.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel,handler:nil))
                self.present(alertController, animated: true, completion: nil)
            })
            
            alertController.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel,handler:nil))
            alertController.view.addSubview(datePicker)
            
            self.present(alertController, animated: true, completion: nil)
        }
        
    }
    @IBOutlet weak var Memo: UITextView!
    @IBOutlet weak var BeginTimeLabel: UILabel!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Finish(_ sender: UIButton) {
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        
        if (Memo.text! != ""){
            ToDosDAO.finishToDo(Id: ID)
            ToDosDAO.saveChanges()
        }else{
            let alertController:UIAlertController=UIAlertController(title: "You need to choose basic informations!", message: "", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default))
            self.present(alertController, animated: true, completion: nil)
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
