	//
//  ToDoDAO.swift
//  Liu Juntong
//
//  Created by Liu Juntong on 2018/3/24.
//  Copyright © 2018年 Echo. All rights reserved.
//

import Foundation
import CoreData
import UserNotifications
    
    class ToDoDAO{
        var context: NSManagedObjectContext
        let now = Date()
        let timeCounter = ToDoTimeCounter.init()
        init(context: NSManagedObjectContext) {
            self.context = context
            
        }
        //Liu: Useful time transfer method
        func transTimeS(time: Date) -> String {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
            let convertedDate = dateFormatter.string(from: time)
            return convertedDate
        }
        
        func transTimeS2(time: Date) -> String {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let convertedDate = dateFormatter.string(from: time)
            return convertedDate
        }
        
        func transTimeI(time: Date) -> Int{
            let timeInterval:TimeInterval = time.timeIntervalSince1970
            let timeStamp = Int(timeInterval)
            return timeStamp
        }
        
        func transTimeST(time: String) -> Date {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
            return dateFormatter.date(from: time)! as Date
        }
        
        func transTimeIT(time: Int) -> Date {
            let timeInterval:TimeInterval = TimeInterval(time)
            let date = Date(timeIntervalSince1970: timeInterval)
            return date as Date
        }
        
        //Liu：Save to database
        func saveChanges(){
            do{
                try context.save()
            }catch let error as NSError{
                print(error)
            }
        }
        
        func addWithFinish(memo:String, beginTime:Date, endTime:Date, period: Int, settingTime:Date){
            let timeInterval:TimeInterval = now.timeIntervalSince1970
            let timeStamp = Int(timeInterval)
            let en = ToDos.entityName
            let ctx = context
            let e = NSEntityDescription.insertNewObject(forEntityName: en, into: ctx)
                as! ToDos
            e.memo = memo
            e.beginTime = beginTime
            e.endTime = endTime
            e.id = timeStamp as NSNumber?
            e.period = period as NSNumber?
            e.settingTime = settingTime
            e.flag = true
            saveChanges()
        }
        
        
        //Liu: Add with begin time and end time
        
        func addWithTime(memo:String, beginTime:Date, endTime:Date, longtermID : Int){
            let timeInterval:TimeInterval = now.timeIntervalSince1970
            let timeStamp = Int(timeInterval)
            let en = ToDos.entityName
            let ctx = context
            let e = NSEntityDescription.insertNewObject(forEntityName: en, into: ctx)
                as! ToDos
            e.memo = memo
            e.beginTime = beginTime
            e.endTime = endTime
            e.id = timeStamp as NSNumber?
            e.period = timeCounter.TimeCounter(beginTime: beginTime, endTime: endTime) as NSNumber?
            e.settingTime = now
            e.flag = false
            if longtermID != 0 {
                e.longtermID = longtermID as NSNumber
            }else{
                e.longtermID = nil
            }
            notificationCreateForToDoWithDate(endTime: endTime, settingTime: now)
            saveChanges()
        }
        //Liu: Add with a period of time (No begin nor end time)
        func addWithPeriod(memo:String, period: Int, longtermID : Int){
            let timeInterval:TimeInterval = now.timeIntervalSince1970
            let timeStamp = Int(timeInterval)
            let en = ToDos.entityName
            let ctx = context
            let e = NSEntityDescription.insertNewObject(forEntityName: en, into: ctx)
                as! ToDos
            e.memo = memo
            e.beginTime = nil
            e.endTime = nil
            e.id = timeStamp as NSNumber?
            e.period = period as NSNumber?
            e.settingTime = now
            e.flag = false
            if longtermID != 0 {
                e.longtermID = longtermID as NSNumber
            }else{
                e.longtermID = nil
            }
            notificationCreateForToDoWithoutDate(period: period)
            saveChanges()
        }
        //Liu: Get all information from database
        func getAll() -> [ToDos]{
            return get(withPredicate: NSPredicate(value: true))
        }
        //Liu: Get method.
        func get(withPredicate p:NSPredicate) -> [ToDos]{
            let en = ToDos.entityName
            let req = NSFetchRequest<NSFetchRequestResult>(entityName: en)
            req.predicate = p
            
            do{
                let resp = try context.fetch(req)
                return resp as! [ToDos]
            }catch let error as NSError{
                print(error)
                return [ToDos]()
            }
        }
        //Liu: Finish a ToDo
        func finishToDo(Id: Int) -> Int {
            let ToDo = getByID(ID: Id)
            if ToDo.flag == false{
                ToDo.flag = true
                ToDo.endTime = now
                saveChanges()
         }
            if ToDo.longtermID != nil {
                return ToDo.longtermID!.intValue
            }else{
                return 0
            }
        }
        
        //Liu: Organized by finish time, return a dictionary with date as the key, ToDo id set as the value. (Could used in Calinder)
        func organizedByDay() -> NSMutableDictionary {
            let ToDoList = getAll()
            let retDic = NSMutableDictionary()
            for i in ToDoList{
                var tempList = [Int]()
                for d in ToDoList{
                    if transTimeS2(time: i.endTime!) == transTimeS2(time: d.endTime!){
                        tempList.append(Int(truncating: d.id!))
                    }
                }
                retDic[transTimeS2(time: i.endTime!)] = tempList
            }
            return retDic
        }
        //Get Today's ToDos (Could be used in Main page)
        func getTodayToDos() -> NSMutableDictionary{
            let ToDoList = getAll()
            let returnList = NSMutableDictionary()
            for i in ToDoList{
                if i.beginTime == nil{
                }else{
                if transTimeS2(time: i.beginTime!) == transTimeS2(time: now){
                    returnList["\(i.id as! Int)"] = i
                }
                }
            }
            return returnList
        }
        
        func getTheDayToDos(TheDay:Date) -> NSMutableDictionary{
            let ToDoList = getAll()
            let returnList = NSMutableDictionary()
            for i in ToDoList{
                if i.beginTime == nil{
                }else{
                    if  transTimeS2(time:i.beginTime!) == transTimeS2(time:TheDay){
                        returnList["\(i.id as! Int)"] = i
                    }
                }
            }
            return returnList
        }
        
        //Get by the end time of the ToDos
        func getByEndTime(Time : Date) -> [ToDos]{
            let ToDoList = getAll()
            var returnList = [ToDos]()
            for t in ToDoList{
                if transTimeS(time: t.endTime!) == transTimeS(time: Time) {
                    returnList.append(t)
                }
            }
            return returnList
        }
        
        //Get by the id of ToDos
        func getByID(ID : Int) -> ToDos{
            let p = NSPredicate(format: "id = %i",ID)
            let en = ToDos.entityName
            let req = NSFetchRequest<NSFetchRequestResult>(entityName: en)
            req.predicate = p
            
            do{
                let resp = try context.fetch(req)
                    let res = resp[0]
                    return res as! ToDos
            }catch let error as NSError{
                print(error)
                return ToDos()
            }
        }
        
        func notificationCreateForToDoWithDate(endTime: Date,settingTime: Date) {
            let content = UNMutableNotificationContent()
            content.title = "Tic-Tac"
            content.body = "Your memo will due on 5 minutes later"
            let end = transTimeI(time: endTime)
            let set = transTimeI(time: settingTime)
            let interval: Int = end-set-300
            print(interval)
            //timeInterval: 用endTime减SettingTime-300(For short time: peroid-300)
            //设置通知触发器
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval:TimeInterval(interval), repeats: false)
            
            //设置请求标识符
            let requestIdentifier = "Group Echo"
            
            //设置一个通知请求
            let request = UNNotificationRequest(identifier: requestIdentifier,
                                                content: content, trigger: trigger)
            
            //将通知请求添加到发送中心
            UNUserNotificationCenter.current().add(request) { error in
                if error == nil {
                    print("Time Interval Notification scheduled: \(requestIdentifier)")
                }
            }
        }
        
        func notificationCreateForToDoWithoutDate(period: Int) {
            let content = UNMutableNotificationContent()
            content.title = "Tic-Tac"
            content.body = "Your memo will due on 5 minutes later"
            //timeInterval: 用endTime减SettingTime-300(For short time: peroid-300)
            //设置通知触发器
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval:TimeInterval(period-300), repeats: false)
            
            //设置请求标识符
            let requestIdentifier = "Group Echo"
            
            //设置一个通知请求
            let request = UNNotificationRequest(identifier: requestIdentifier,
                                                content: content, trigger: trigger)
            
            //将通知请求添加到发送中心
            UNUserNotificationCenter.current().add(request) { error in
                if error == nil {
                    print("Time Interval Notification scheduled: \(requestIdentifier)")
                }
            }
        }
        
        //Delete by id of ToDos.
        func deletByID(Id: Int){
            let idss = getByID(ID: Id)
            context.delete(idss)
            saveChanges()
        }
    }
