//
//  LongTermDAO.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/4/26.
//  Copyright © 2018年 Echo. All rights reserved.
//

import Foundation
import CoreData

class LongTermDAO {
    var context: NSManagedObjectContext
    let now = Date()
    init(context: NSManagedObjectContext) {
        self.context = context
    }
    
    //Save to database
    func saveChanges(){
        do{
            try context.save()
        }catch let error as NSError{
            print(error)
        }
    }
    
    //Zhang: Add a new longterm task with time limit into the database
    func addWithTime(name:String, overview:String, startTime:Date, endTime:Date, estimatedTime: Date){ //estimated time 的类型有待商榷
        let timeInterval:TimeInterval = now.timeIntervalSince1970
        let timeStamp = Int(timeInterval)//得到现在时刻的时间戳，并换算成int
        let en = LongTerms.entityName
        let ctx = context
        let e = NSEntityDescription.insertNewObject(forEntityName: en, into: ctx)
            as! LongTerms //不懂 照着做
        e.id = timeStamp as NSNumber
        e.name = name
        e.overview = overview
        e.startTime = startTime
        e.endTime = endTime
        e.estimatedTime = estimatedTime
        e.timeSoFar = 0 //NSNumber是否可以直接存为0有待调查
        e.settingTime = now
        e.done = false
        e.hasDDL = true
        saveChanges()
    }
    
    //Zhang: Add a new longterm task which does not have ddl
    func addWithoutTime(name:String, overview :String){
        let timeInterval:TimeInterval = now.timeIntervalSince1970
        let timeStamp = Int(timeInterval)//得到现在时刻的时间戳，并换算成int
        let en = LongTerms.entityName
        let ctx = context
        let e = NSEntityDescription.insertNewObject(forEntityName: en, into: ctx)
            as! LongTerms //不懂 照着做
        e.id = timeStamp as NSNumber
        e.name = name
        e.overview = overview
        e.startTime = nil
        e.endTime = nil
        e.estimatedTime = nil
        e.timeSoFar = 0
        e.settingTime = now
        e.done = false
        e.hasDDL = false
        saveChanges()
    }
    
    //get method of LongTerm object
    func get(withPredicate p:NSPredicate) -> [LongTerms]{
        let en = LongTerms.entityName
        let req = NSFetchRequest<NSFetchRequestResult>(entityName: en)
        req.predicate = p
        do{
            let resp = try context.fetch(req)
            return resp as! [LongTerms]
        }catch let error as NSError{
            print(error)
            return [LongTerms]()
        }
    }
    //这两个从数据库里获取对象的函数不是很懂
    func getAll() -> [LongTerms]{
        return get(withPredicate: NSPredicate(value: true))
    }
    
    //Get LongTerm by the name of it 此方法仿照ljt的，没跑过不知道可不可以
    func getById(id : Int) -> [LongTerms]{
        let p = NSPredicate(format: "id = %i",id)
        let en = LongTerms.entityName
        let req = NSFetchRequest<NSFetchRequestResult>(entityName: en)
        req.predicate = p
        do{
            let resp = try context.fetch(req)
            return resp as! [LongTerms]
        }catch let error as NSError{
            print(error)
            return [LongTerms]()
        }
    }
    
    func acumulateTime(id : Int, time : Int){
        let longTerms = getById(id : id)
        for l in longTerms {
            let TimeSoFar = l.timeSoFar
            l.timeSoFar += time as NSNumber//?NSnumber怎么转成int
        }
        saveChanges()
    }
    
    //Delete LongTerm by the name of it
    func deletByName(name: String){
        //待完成
    }
}

