//
//  NewLongTermViewController.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/5/2.
//  Copyright © 2018年 Echo. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class NewLongTermViewController : UIViewController {
    
    @IBOutlet weak var nameEntry: UITextField!
    @IBOutlet weak var descriptionEntry: UITextField!
    @IBOutlet weak var startTimeLabel: UILabel!
    @IBOutlet weak var endingTimeLabel: UILabel!
    @IBOutlet weak var estimatedTimeLabel: UILabel!
    @IBOutlet weak var typeSwitch: UISwitch!
    @IBOutlet weak var startTimeButton: UIButton!
    @IBOutlet weak var endingTimeButton: UIButton!
    @IBOutlet weak var estimatedTimeButton: UIButton!
    
    var longterm : LongTerms? ///
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    //next part are functions about selecting time in data picker and show them in related time labels
    @IBAction func selectBeginDate(_ sender: UIButton) {
        timeSelect(timeLabel: self.startTimeLabel)
    }
    
    
    @IBAction func selectEndDate(_ sender: UIButton) {
        timeSelect(timeLabel : self.endingTimeLabel)
    }
    
    
    @IBAction func selectEstimatedTime(_ sender: UIButton) {
        timeSelect(timeLabel: self.estimatedTimeLabel)
    }
    
    
    func timeSelect(timeLabel : UILabel){
        let alertController:UIAlertController=UIAlertController(title: "\n\n\n\n\n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        // 初始化 datePicker
        let datePicker = UIDatePicker( )
        // 设置样式，当前设为同时显示日期和时间
        datePicker.datePickerMode = UIDatePickerMode.dateAndTime
        // 设置默认时间
        datePicker.date = NSDate() as Date
        // 响应事件（只要滚轮变化就会触发）
        // datePicker.addTarget(self, action:Selector("datePickerValueChange:"), forControlEvents: UIControlEvents.ValueChanged)
        alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default){
            (alertAction)in
            timeLabel.text = TimeTransfer.transTimeS(time: datePicker.date)
        })
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel,handler:nil))
        alertController.view.addSubview(datePicker)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    //实现开关的功能 关时：3个按钮不可用 label中字体发生变化
    @IBAction func switchTrigger(_ sender: UISwitch) {
        if (!self.typeSwitch.isOn){
            self.startTimeButton.isUserInteractionEnabled = true
            self.endingTimeLabel.isUserInteractionEnabled = true
            self.estimatedTimeLabel.isUserInteractionEnabled = true
            enableLabel(label : self.startTimeLabel)
            enableLabel(label : self.endingTimeLabel)
            enableLabel(label : self.estimatedTimeLabel)
        }else{
            self.startTimeButton.isUserInteractionEnabled = false
            self.endingTimeLabel.isUserInteractionEnabled = false
            self.estimatedTimeLabel.isUserInteractionEnabled = false
            disableLabel(label : self.startTimeLabel)
            disableLabel(label : self.endingTimeLabel)
            disableLabel(label : self.estimatedTimeLabel)
        }
    }
    
    
    //开关关闭时label状态 ： 使label中的字体颜色变灰 将label字体变为“Disable”
    func disableLabel(label:UILabel){
        label.text = "Disable"
        label.textColor = UIColor.gray
    }
    //label恢复正常
    func enableLabel(label:UILabel){
        label.text = "Unknown"
        label.textColor = UIColor.black
    }
    
    
    //操作提示弹窗 （非选择）
    func alertOnlyConfirm(title : String, message : String){
        let alertController:UIAlertController=UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default))
        self.present(alertController, animated: true, completion: nil)//不确定这里的self是什么 有可能要改成一个VC（把VC当参数传到这个方法里）
    }
    
    
    //按下confirm按钮会发生的事情
    @IBAction func confirm(_ sender: UIButton) {
        
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let longtermsDAO = LongTermDAO(context: context)
        
        //按下confirm按钮，对此界面中的UI控件中的值进行判断
        if (self.typeSwitch.isOn){
            //开关关时
            if (nameEntry.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) && (startTimeLabel.text! != "Unknown")&&(endingTimeLabel.text! != "Unknown")&&(estimatedTimeLabel.text! != "Unknown"){
                //所有必填信息都填好时
                if TimeTransfer.transTimeST(time: startTimeLabel.text!) < TimeTransfer.transTimeST(time: endingTimeLabel.text!) {//判断开始时间和结束时间的先后
                    //时间没有出现错误时
                    longtermsDAO.addWithTime(name: nameEntry.text!, overview: descriptionEntry.text!, startTime: TimeTransfer.transTimeST(time: startTimeLabel.text!), endTime: TimeTransfer.transTimeST(time: endingTimeLabel.text!), estimatedTime : TimeTransfer.transTimeST(time: estimatedTimeLabel.text!))//用获取的信息创建一个有ddl的longterm
                    alertOnlyConfirm(title: "Done", message: "Create successfully.")
                    //弹窗提示创建成功，待改进：创建判断+创建失败的提示
                }else{
                    //时间出错时
                    alertOnlyConfirm(title: "Error", message: "Failed creating: start time can't be later than ending time.")
                }
            }else{
                //有必填信息没有填时
                alertOnlyConfirm(title: "Error", message: "Failed creating: all required information have to be completed.")
            }
        }else{
            if(nameEntry.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty){//检查nameEntry中是否只有空字符
                //创建一个没有ddl的longterm
                longtermsDAO.addWithoutTime(name: nameEntry.text!, overview: descriptionEntry.text!)
                //弹窗提示创建成功，待改进：创建判断+创建失败的提示
                alertOnlyConfirm(title: "Done", message: "Create successfully.")
            } else{
                alertOnlyConfirm(title: "Error", message: "Failed creating: task name can't be empty.")
            }
        }
        
        
    }
}

