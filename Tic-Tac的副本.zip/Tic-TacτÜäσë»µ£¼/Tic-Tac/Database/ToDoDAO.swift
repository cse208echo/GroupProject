    //
    //  ToDoDAO.swift
    //  Liu Juntong
    //
    //  Created by Liu Juntong on 2018/3/24.
    //  Copyright © 2018年 Echo. All rights reserved.
    //
    
    import Foundation
    import CoreData
    import UserNotifications
    
    class ToDoDAO{
        var context: NSManagedObjectContext
        let now = Date()
        let timeCounter = ToDoTimeCounter.init()
        init(context: NSManagedObjectContext) {
            self.context = context
        }
        
        //Liu：Save to database
        func saveChanges(){
            do{
                try context.save()
            }catch let error as NSError{
                print(error)
            }
        }
        
        //Liu: Add with begin time and end time
        func addWithTime(memo:String, beginTime:Date, endTime:Date, priority:Int16){
            let timeInterval:TimeInterval = now.timeIntervalSince1970
            let timeStamp = Int(timeInterval)
            let en = ToDos.entityName
            let ctx = context
            
            let e = NSEntityDescription.insertNewObject(forEntityName: en, into: ctx)
                as! ToDos
            e.memo = memo
            e.beginTime = beginTime
            e.endTime = endTime
            e.priority = priority as NSNumber?
            e.id = timeStamp as NSNumber?
            e.period = timeCounter.TimeCounter(beginTime: beginTime, endTime: endTime) as NSNumber?
            e.settingTime = now
            e.flag = false
            notificationCreateForToDoWithDate(endTime: endTime, settingTime: now)
            saveChanges()
        }
        //Liu: Add with a period of time (No begin nor end time)
        func addWithPeriod(memo:String, period: Int, priority: Int16){
            let timeInterval:TimeInterval = now.timeIntervalSince1970
            let timeStamp = Int(timeInterval)
            let en = ToDos.entityName
            let ctx = context
            let e = NSEntityDescription.insertNewObject(forEntityName: en, into: ctx)
                as! ToDos
            e.memo = memo
            e.beginTime = nil
            e.endTime = nil
            e.priority = priority as NSNumber?
            e.id = timeStamp as NSNumber?
            e.period = period as NSNumber?
            e.settingTime = now
            e.flag = false
            notificationCreateForToDoWithoutDate(period: period)
            saveChanges()
        }
        //Liu: Get all information from database
        func getAll() -> [ToDos]{
            return get(withPredicate: NSPredicate(value: true))
        }
        //Liu: Get method.
        func get(withPredicate p:NSPredicate) -> [ToDos]{
            let en = ToDos.entityName
            let req = NSFetchRequest<NSFetchRequestResult>(entityName: en)
            req.predicate = p
            
            do{
                let resp = try context.fetch(req)
                return resp as! [ToDos]
            }catch let error as NSError{
                print(error)
                return [ToDos]()
            }
        }
        
        //Liu: Finish a ToDo
        func finishToDo(ID : Int) {
            let ToDosL = getByID(ID:ID)
            for t in ToDosL{
                if t.flag == false{
                    t.flag = true
                    t.endTime = now
                    if t.longTermId != nil {
                        //调用一个方法 寻找匹配longterm对象 添加时间
                        var l = matchLongTerm(longTermId : t.longTermId)//String? 和 String 不是一个类型
                        l.acumulateTume//这里我想调用longterm类里的一个函数去改动一个longterm类对象的一个属性
                    }
                }
            }
        }
        
        //Zhang: match a Todos with associcated LongTerms object by its longTermName
        func matchLongTerm(longTermId : Int) -> LongTerms{
            let longTermDAO = LongTermDAO(context:context)
            let LongTermL =  longTermDAO.getById(id: longTermId)
            //获取对应id的longterm
            for l in LongTermL {
                if l.done == false{
                    //若此longterm未完成 返回它
                    return l
                }
            }
            
            //Liu: Organized by finish time, return a dictionary with date as the key, ToDo id set as the value. (Could used in Calinder)
            func organizedByDay() -> NSMutableDictionary {
                let ToDoList = getAll()
                let retDic = NSMutableDictionary()
                for i in ToDoList{
                    var tempList = [Int]()
                    for d in ToDoList{
                        if TimeTransfer.transTimeS2(time: i.endTime!) == TimeTransfer.transTimeS2(time: d.endTime!){
                            tempList.append(Int(truncating: d.id!))
                        }
                    }
                    retDic[TimeTransfer.transTimeS2(time: i.endTime!)] = tempList
                }
                return retDic
            }
            //Get Today's ToDos (Could be used in Main page)
            func getTodayToDos() -> NSMutableDictionary{
                let ToDoList = getAll()
                let returnList = NSMutableDictionary()
                for i in ToDoList{
                    if i.beginTime == nil{
                    }else{
                        if TimeTransfer.transTimeS2(time: i.beginTime!) == TimeTransfer.transTimeS2(time: now){
                            returnList["\(i.id as! Int)"] = i
                        }
                    }
                }
                return returnList
            }
            
            func getTheDayToDos(TheDay:Date) -> NSMutableDictionary{
                let ToDoList = getAll()
                let returnList = NSMutableDictionary()
                for i in ToDoList{
                    if i.beginTime == nil{
                    }else{
                        if TimeTransfer.transTimeS2(time: i.beginTime!) == TimeTransfer.transTimeS2(time: TheDay){
                            returnList["\(i.id as! Int)"] = i
                        }
                    }
                }
                return returnList
            }
            
            //Get by the end time of the ToDos
            func getByEndTime(Time : Date) -> [ToDos]{
                let ToDoList = getAll()
                var returnList = [ToDos]()
                for t in ToDoList{
                    if TimeTransfer.transTimeS(time: t.endTime!) == TimeTransfer.transTimeS(time: Time) {
                        returnList.append(t)
                    }
                }
                return returnList
            }
            
            //Get by the id of ToDos
            func getByID(ID : Int) -> [ToDos]{
                let p = NSPredicate(format: "id = %i",ID)
                let en = ToDos.entityName
                let req = NSFetchRequest<NSFetchRequestResult>(entityName: en)
                req.predicate = p
                
                do{
                    let resp = try context.fetch(req)
                    return resp as! [ToDos]
                    
                }catch let error as NSError{
                    print(error)
                    return [ToDos]()
                }
            }
            
            func notificationCreateForToDoWithDate(endTime: Date,settingTime: Date) {
                let content = UNMutableNotificationContent()
                content.title = "Tic-Tac"
                content.body = "Your memo will due on 5 minutes later"
                let end = TimeTransfer.transTimeI(time: endTime)
                let set = TimeTransfer.transTimeI(time: settingTime)
                let interval: Int = end-set-300
                print(interval)
                //timeInterval: 用endTime减SettingTime-300(For short time: peroid-300)
                //设置通知触发器
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval:TimeInterval(interval), repeats: false)
                
                //设置请求标识符
                let requestIdentifier = "Group Echo"
                
                //设置一个通知请求
                let request = UNNotificationRequest(identifier: requestIdentifier,
                                                    content: content, trigger: trigger)
                
                //将通知请求添加到发送中心
                UNUserNotificationCenter.current().add(request) { error in
                    if error == nil {
                        print("Time Interval Notification scheduled: \(requestIdentifier)")
                    }
                }
            }
            
            func notificationCreateForToDoWithoutDate(period: Int) {
                let content = UNMutableNotificationContent()
                content.title = "Tic-Tac"
                content.body = "Your memo will due on 5 minutes later"
                //timeInterval: 用endTime减SettingTime-300(For short time: peroid-300)
                //设置通知触发器
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval:TimeInterval(period-300), repeats: false)
                
                //设置请求标识符
                let requestIdentifier = "Group Echo"
                
                //设置一个通知请求
                let request = UNNotificationRequest(identifier: requestIdentifier,
                                                    content: content, trigger: trigger)
                
                //将通知请求添加到发送中心
                UNUserNotificationCenter.current().add(request) { error in
                    if error == nil {
                        print("Time Interval Notification scheduled: \(requestIdentifier)")
                    }
                }
            }
            
            //Delete by id of ToDos.
            func deletByID(Id: Int){
                let idss = getAll()
                for i in idss {
                    context.delete(i)
                }
                saveChanges()
            }
        }
    }
