//
//  ViewController.swift
//  Liu Juntong
//
//  Created by Liu Juntong on 2018/3/19.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //这个part里面所有的代码都是做测试用的测试用例，正式程序里面不是这样的。
        /*let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        //ToDosDAO.deletByID(Id: 10225)
        let users = ToDosDAO.getAll()
        for i in users{
            //print("i:\(i.memo! as String),\(i.beginTime! as Date),\(i.endTime! as Date),\(i.priority as! Int),\(i.id as! Int),\(i.flag )")
            print("i:\(i.memo! as String),\(i.period as! Int ),\(i.id as! Int),\(i.flag)")
            ForTest.insertText("i:\(i.id as! Int), \(i.memo! as String)\n")
        }
        let missions = ToDosDAO.getTodayToDos()
        let T = missions.allKeys
        print(T)
        ToDosDAO.finishToDo(ID: 1522833231)*/
        //let ToDoDic = ToDosDAO.organizedByDay()
        //print(ToDoDic)
        //let TDTC = ToDoTimeCounter.init()
        
        //print(TDTC.TimeCounter(beginTime: users[1].beginTime!, endTime: users[1].endTime!))
        //print(TDTC.SuitableTimeCounter())
        //print("Today ToDos: \(ToDosDAO.getTodayToDos())")
        let ToDoes = getMemoToday()
        let ids = ToDoes.allKeys
        for i in ids{
            let obj: ToDos = ToDoes.value(forKey: i as! String) as! ToDos
            ForTest.insertText("i:\(obj.id as! Int), \(obj.memo! as String)\n")
        }
        
    }
    
    func getMemoToday() -> NSMutableDictionary{
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        let missions = ToDosDAO.getTodayToDos()
        return missions
    }
    
    @IBOutlet weak var ForTest: UITextView!
    
    @IBAction func Calendar(_ sender: UIButton) {
    }
    
    @IBAction func addToDo(_ sender: Any) {
    }
    
}

