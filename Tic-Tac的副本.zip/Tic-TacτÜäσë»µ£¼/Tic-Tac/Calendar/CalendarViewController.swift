//
//  CalendarViewController.swift
//  Tic-Tac
//
//  Created by mac on 2018/4/25.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit

enum MyTheme {
    case light
    case dark
}

class CalendarViewController: UIViewController {
    var theme = MyTheme.light
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.title = "My Calender"
        self.navigationController?.navigationBar.isTranslucent=false
        self.view.backgroundColor=Style.bgColor
        
        view.addSubview(calenderView)
        calenderView.topAnchor.constraint(equalTo: view.topAnchor, constant: 20).isActive=true
        calenderView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -12).isActive=true
        calenderView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 12).isActive=true
        calenderView.heightAnchor.constraint(equalToConstant: 300).isActive=true
        calenderView.isHidden = false
        
        //        let rightBarBtn = UIBarButtonItem(title: "Dark", style: .plain, target: self, action: #selector(rightBarBtnAction))
        //        self.navigationItem.rightBarButtonItem = rightBarBtn
    }
    
    @IBAction func Confirm(_ sender: UIButton) {
        
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        calenderView.myCollectionView.collectionViewLayout.invalidateLayout()
    }
    
    @objc func rightBarBtnAction(sender: UIBarButtonItem) {
        if theme == .dark {
            sender.title = "Dark"
            theme = .light
            Style.themeLight()
        } else {
            sender.title = "Light"
            theme = .dark
            Style.themeDark()
        }
        self.view.backgroundColor=Style.bgColor
        calenderView.changeTheme()
    }
    
    let calenderView: CalenderView = {
        //改！let v=CalenderView(theme: MyTheme.dark)
        let v=CalenderView(theme: MyTheme.light)
        v.translatesAutoresizingMaskIntoConstraints=false
        return v
    }()
    
    
}
