//
//  RecordViewController.swift
//  Tic-Tac
//
//  Created by mac on 2018/5/10.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import CoreData

class RecordViewController: UITableViewController {
    var items: [ToDos]
    var indexPaths : [IndexPath]
    public var TheDay : Date
    public var StringT = ""
    
    required init?(coder aDecoder: NSCoder) {
        items = []
        indexPaths = []
        TheDay = Date()
        super.init(coder: aDecoder)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = tableView.indexPathForSelectedRow
        let item = items[(indexPath?.row)!]
        if let TDVC = segue.destination as? ToDoViewController{
            TDVC.ThisToDo = item
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.separatorStyle = UITableViewCellSeparatorStyle.none
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        let missions = ToDosDAO.getTheDayToDos(TheDay: TheDay)
        items = missions.allValues as! [ToDos]
        let newRowIndex = items.count
        if !(newRowIndex==0) {
            for i in 0...newRowIndex{
                indexPaths = [IndexPath(row: i, section: 0)]
            }
        }
        
        readDataAndAdd()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func readDataAndAdd(){
        if !(indexPaths.endIndex==0) {
            for i in indexPaths{
                tableView.insertRows(at: [i], with: .top)
            }
        }
    }
    
    func configureCheckmark(for cell: UITableViewCell,with item: ToDos) {
        if item.flag{
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
    }
    
    var TextView: UITextView!
    var textLabel: UILabel!
    
    func configureText(for cell: UITableViewCell,with item: ToDos) {
        TextView = cell.viewWithTag(1000) as! UITextView
        TextView.text = item.memo
        TextView.backgroundColor = NSKeyedUnarchiver.unarchiveObject(with: item.color! as Data) as? UIColor
        
        textLabel = cell.viewWithTag(600) as! UILabel
        textLabel.text = TimeTransfer.transTimeS3(time: item.beginTime!) 
    }
    
    
    // MARK:- TableView Delegates
    override func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var newHeight = tableView.rowHeight
        newHeight = CGFloat(100)
        return newHeight
    }
    
    override func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Todo", for: indexPath)
        let item = items[indexPath.row]
        configureText(for: cell, with: item )
        configureCheckmark(for: cell, with: item )
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
        if tableView.cellForRow(at: indexPath) != nil {
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }
    
}

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

