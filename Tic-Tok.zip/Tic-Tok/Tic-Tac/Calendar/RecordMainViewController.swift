//
//  RecordMainViewController.swift
//  Tic-Tac
//
//  Created by mac on 2018/5/10.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit

class RecordMainViewController: UIViewController {
    public var TheDay = Date()
    public var StringT = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

  
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let RDVC = segue.destination as? RecordViewController{
            RDVC.TheDay = TheDay
            RDVC.StringT = StringT
        }
    }


}
