//
//  ViewController.swift
//  Liu Juntong
//
//  Created by Liu Juntong on 2018/3/19.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {
    var finishID = 001
    var finishFlag = false
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let TLVC = segue.destination as? TimelineViewController{
                TLVC.finishID = finishID
                TLVC.finishToDoFlag = finishFlag
            }
        if let VC = segue.source as? periodToDoViewController{
            VC.reloadInputViews()
        }
            
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func getMemoToday() -> NSMutableDictionary{
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        let missions = ToDosDAO.getTodayToDos()
        return missions
    }
    
    
    
}

