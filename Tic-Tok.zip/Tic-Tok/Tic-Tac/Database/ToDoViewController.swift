//
//  ToDoViewController.swift
//  Tic-Tac
//
//  Created by Liu Juntongon 5/7/18.
//  Copyright © 2018 Echo. All rights reserved.
//

import UIKit

class ToDoViewController: UIViewController {
    var ToDosDAO: ToDoDAO?
    var ThisToDo: ToDos?
    var finishFlag = false
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (sender as! UIButton).currentImage == #imageLiteral(resourceName: "done") {
            if let TLVC = segue.destination as? ViewController{
                TLVC.finishID = ThisToDo?.id as! Int
                TLVC.finishFlag = finishFlag
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        ToDosDAO = ToDoDAO(context: context)
        Memo.insertText((ThisToDo?.memo!)!)
        BeginTimeLabel.text = transTimeS(time: (ThisToDo?.beginTime!)!)
        EndTimeLabel.text = transTimeS(time: (ThisToDo?.endTime!)!)
        Memo.isEditable = false
        // Do any additional setup after loading the view.
    }
    
    func transTimeS(time: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let convertedDate = dateFormatter.string(from: time)
        return convertedDate
    }
    
    func transTimeST(time: String) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return dateFormatter.date(from: time)!
    }

    @IBOutlet weak var EndTimeLabel: UILabel!
    @IBAction func EndTimeButton(_ sender: UIButton) {
        if !(ThisToDo?.flag)! {
            let alertController:UIAlertController=UIAlertController(title: "\n\n\n\n\n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
            let datePicker = UIDatePicker( )
            datePicker.datePickerMode = UIDatePickerMode.dateAndTime
            datePicker.date = NSDate() as Date
            alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default){
                (alertAction)in
                    self.EndTimeLabel.text = self.transTimeS(time: datePicker.date)
                    self.ToDosDAO?.deletByID(Id: self.ThisToDo?.id as! Int)
                    self.ToDosDAO?.addWithTime(memo: self.Memo.text, beginTime: self.transTimeST(time: self.BeginTimeLabel.text!), endTime: datePicker.date, longtermID: 0)
            })
            
            alertController.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel,handler:nil))
            alertController.view.addSubview(datePicker)
            
            self.present(alertController, animated: true, completion: nil)
        }
        
    }
    @IBOutlet weak var Memo: UITextView!
    @IBOutlet weak var BeginTimeLabel: UILabel!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Finish(_ sender: UIButton) {
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let LongtermsDAO = LongtermDAO(context: context)
        
        if (ThisToDo?.flag==false){
            let state = ToDosDAO?.finishToDo(Id: ThisToDo?.id as! Int)
            finishFlag = true
            if state != 0 {
                LongtermsDAO.acumulateTime(id: ThisToDo?.longtermID as! Int, time: ThisToDo?.period as! Int)
            }
        }else{
            let alertController:UIAlertController=UIAlertController(title: "You already finished this to do", message: "", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default))
            self.present(alertController, animated: true, completion: nil)
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
