//
//  periodToDoViewController.swift
//  Tic-Tac
//
//  Created by 尹笑康 on 2018/5/16.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import CoreData

class periodToDoViewController: UITableViewController {
    
    var dele : AppDelegate
    var context : NSManagedObjectContext
    var ToDosDAO : ToDoDAO
    var indexPaths : [IndexPath] = []
    var Items: [ToDos] = []
    var timeLeft = 0
    required init?(coder aDecoder: NSCoder) {
        dele = (UIApplication.shared.delegate as! AppDelegate)
        context = dele.persistentContainer.viewContext
        ToDosDAO = ToDoDAO(context: context)
        
        
        super.init(coder: aDecoder)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.separatorStyle = UITableViewCellSeparatorStyle.none
        navigationController?.navigationBar.prefersLargeTitles = true
        readDataAndAdd()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func readDataAndAdd(){
        Items = ToDosDAO.getperiodToDos2(timeleft: timeLeft)
        let newRowIndex = Items.count
        if !(newRowIndex==0) {
            for i in 0...newRowIndex{
                indexPaths = [IndexPath(row: i, section: 0)]
            }
        }
        if !(indexPaths.endIndex==0) {
            for i in indexPaths{
                tableView.insertRows(at: [i], with: .top)
            }
        }
    }
    
    var TextView: UITextView!
    
    func configureText(for cell: UITableViewCell,with item: ToDos) {
        TextView = cell.viewWithTag(1000) as! UITextView
        TextView.text = item.memo
    }
    
    
    // MARK:- TableView Delegates
    override func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int {
        return Items.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var newHeight = tableView.rowHeight
        newHeight = CGFloat(100)
        return newHeight
    }
    
    override func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Todo", for: indexPath)
        let item = Items[indexPath.row]
        configureText(for: cell, with: item )
        return cell
    }
    
    override func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
        if tableView.cellForRow(at: indexPath) != nil {
            let item = Items[(indexPath.row)]
            ToDosDAO.givePeriodBeginTime(Id: item.id as! Int)
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }
    
    override func tableView(_ tableView: UITableView,commit editingStyle: UITableViewCellEditingStyle,forRowAt indexPath: IndexPath){
        let item = Items[indexPath.row]
        let id = item.id
        ToDosDAO.deletByID(Id: id as! Int)
        Items.remove(at: indexPath.row)
        let indexPaths = [indexPath]
        tableView.deleteRows(at: indexPaths, with: .automatic)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
