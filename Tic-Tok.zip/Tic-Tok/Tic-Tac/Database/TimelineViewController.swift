//
//  TimelineViewController.swift
//  Tic-Tac
//
//  Created by Liu Juntong on 2018/5/6.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import CoreData

class TimelineViewController: UITableViewController {
    var ToDosDAO : ToDoDAO
    var indexPaths : [IndexPath]
    var sortedItems: [ToDos]
    var finishID = 110
    var finishToDoFlag = false
    var Timeleft = 0
    required init?(coder aDecoder: NSCoder) {
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        ToDosDAO = ToDoDAO(context: context)
        let missions = ToDosDAO.getTodayToDos()
        let items = missions.allValues as! [ToDos]
        sortedItems = items.sorted(by: {$0.beginTime!<$1.beginTime!})
        indexPaths = []
        let newRowIndex = items.count
        if !(newRowIndex==0) {
            for i in 0...newRowIndex{
                indexPaths = [IndexPath(row: i, section: 0)]
            }
        }
        
        super.init(coder: aDecoder)
}
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "JumpToDo"{
        let indexPath = tableView.indexPathForSelectedRow
        let item = sortedItems[(indexPath?.row)!]
            if let TDVC = segue.destination as? ToDoViewController{
                TDVC.ThisToDo = item
                
            }
        }else if segue.identifier=="periodToDo"{
            if let PDVC = segue.destination as? periodToDoViewController{
                PDVC.timeLeft = Timeleft
        }
    }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.separatorStyle = UITableViewCellSeparatorStyle.none
        navigationController?.navigationBar.prefersLargeTitles = true
        print(finishToDoFlag)
        if finishToDoFlag == true{
            print("recommand")
            perform(#selector(TimelineViewController.recommand), with: self, afterDelay: 1)
        }
        readDataAndAdd()
        
        
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
}
    @objc func recommand(){
        let nowTime = Date()
        let periodToDos = ToDosDAO.getperiodToDos()
        var count = 0;
        var current = 0;
        var recommandList: [ToDos] = []
        let times:Calendar = NSCalendar.current
        let Zero = times.date(bySettingHour: 23, minute: 59, second: 59, of: Date())
        if periodToDos != []{
        for i in sortedItems{
            if i.id as! Int != finishID {
                count = count + 1
            }else{
                current = count
            }
        }
                if current < (sortedItems.count-1){
                    let nextToDo = sortedItems[current+1]
                    Timeleft = TimeTransfer.transTimeI(time: nextToDo.beginTime!) - TimeTransfer.transTimeI(time: nowTime)
                    for j in periodToDos{
                        if Timeleft > j.period as! Int{
                            recommandList.append(j)
                        }
                    }
                }else{
                    Timeleft = TimeTransfer.transTimeI(time: Zero!) - TimeTransfer.transTimeI(time: nowTime)
                    for j in periodToDos{
                        if Timeleft > j.period as! Int{
                            recommandList.append(j)
                        }
                    }
                }
            
        }
        if !recommandList.isEmpty{
        let alertController:UIAlertController=UIAlertController(title: "You Get Some Time", message: "You Have some spare time now, do you want to finish some work?", preferredStyle: UIAlertControllerStyle.actionSheet)
        alertController.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default){
            (alertAction)in
            self.performSegue(withIdentifier: "periodToDo", sender: UIAlertAction())
        })
        alertController.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.cancel,handler:nil))
        
        
        self.present(alertController, animated: true, completion: nil)
        }
    }
    
    
    func readDataAndAdd(){
        if !(indexPaths.endIndex==0) {
            for i in indexPaths{
                tableView.insertRows(at: [i], with: .top)
            }
        }
    }
    
    func configureCheckmark(for cell: UITableViewCell,with item: ToDos) {
        if item.flag{
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
    }
    
    var TextView: UITextView!
    var textLabel: UILabel!
    
    func configureText(for cell: UITableViewCell,with item: ToDos) {
        TextView = cell.viewWithTag(1000) as! UITextView
        TextView.text = item.memo
        TextView.backgroundColor = NSKeyedUnarchiver.unarchiveObject(with: item.color! as Data) as? UIColor
        
        textLabel = cell.viewWithTag(600) as! UILabel
        textLabel.text = TimeTransfer.transTimeS3(time: item.beginTime!) 
    }
 
    
    // MARK:- TableView Delegates
    override func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int {
        return sortedItems.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var newHeight = tableView.rowHeight
        newHeight = CGFloat(120)
        return newHeight
    }
    
    override func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Todo", for: indexPath)
        let item = sortedItems[indexPath.row]
        configureText(for: cell, with: item )
        configureCheckmark(for: cell, with: item )
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
        if tableView.cellForRow(at: indexPath) != nil {
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }
    
    
    override func tableView(_ tableView: UITableView,commit editingStyle: UITableViewCellEditingStyle,forRowAt indexPath: IndexPath){
        let item = sortedItems[indexPath.row]
        let id = item.id
        ToDosDAO.deletByID(Id: id as! Int)
        sortedItems.remove(at: indexPath.row)
        let indexPaths = [indexPath]
        tableView.deleteRows(at: indexPaths, with: .automatic)
}
    
}
