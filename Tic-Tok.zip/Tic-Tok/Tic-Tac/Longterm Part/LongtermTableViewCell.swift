//
//  LongtermTableViewCell.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/5/14.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit

class LongtermTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!    
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var progress: UIProgressView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //        progress = UIProgressView(progressViewStyle: .default)
        //        progress.frame = CGRect(x: 0, y: 0, width: 100, height: 30)
        //        progress.setProgress(0.5, animated: true)
        //        progress.progressTintColor = UIColor.green //进度颜色
        //        progress.trackTintColor = UIColor.yellow //剩余进度颜色
        //通过改变进度条高度(宽度不变，高度变为默认的2倍)
        progress.transform = CGAffineTransform(scaleX: 1.0, y:4.5)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}



