//
//  SelectTime.swift
//  Tic-Tac
//
//  Created by unicorn on 2018/5/14.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit

class SelectTime {
    static func dateAndTimePicker() -> UIDatePicker{
        // 初始化 datePicker
        let datePicker = UIDatePicker( )
        // 设置样式，当前设为同时显示日期和时间
        datePicker.datePickerMode = UIDatePickerMode.dateAndTime
        // 设置默认时间
        datePicker.date = NSDate() as Date
        return datePicker
    }
    
    static func timerPicker() -> UIDatePicker{
        // 初始化 datePicker
        let datePicker = UIDatePicker( )
        // 设置样式，当前设为同时显示日期和时间
        datePicker.datePickerMode = UIDatePickerMode.countDownTimer
        // 设置默认时间
        datePicker.date = NSDate() as Date
        return datePicker
    }
}


