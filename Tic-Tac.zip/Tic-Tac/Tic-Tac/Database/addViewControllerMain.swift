//
//  addViewControllerMain.swift
//  Tic-Tac
//
//  Created by mac on 2018/4/1.
//  Copyright © 2018年 Echo. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class addViewControllerMain: UIViewController{
    @IBAction func LongtermSwitch(_ sender: UISwitch) {
        if sender.isOn {
            switch SelectBar.selectedSegmentIndex
            {
            case 0:
                FirstPage.isHidden = true
                SecondPage.isHidden = true
                ThirdPage.isHidden = false
                FourthPage.isHidden = true
            case 1:
                FirstPage.isHidden = true
                SecondPage.isHidden = true
                ThirdPage.isHidden = true
                FourthPage.isHidden = false
            default:
                break;
            }
        }else {
            switch SelectBar.selectedSegmentIndex
        {
            case 0:
            FirstPage.isHidden = false
            SecondPage.isHidden = true
            ThirdPage.isHidden = true
            FourthPage.isHidden = true
            case 1:
            FirstPage.isHidden = true
            SecondPage.isHidden = false
            ThirdPage.isHidden = true
            FourthPage.isHidden = true
            default:
            break;
        }
        }
    }
    
    @IBAction func indexChanged(sender: UISegmentedControl) {
        switch SelectBar.selectedSegmentIndex
        {
        case 0:
            FirstPage.isHidden = false
            SecondPage.isHidden = true
            ThirdPage.isHidden = true
            FourthPage.isHidden = true
        case 1:
            FirstPage.isHidden = true
            SecondPage.isHidden = false
            ThirdPage.isHidden = true
            FourthPage.isHidden = true
        default:
            break;
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        FirstPage.isHidden = false
        SecondPage.isHidden = true
        ThirdPage.isHidden = true
        FourthPage.isHidden = true
        
    }
    
    @IBAction func CancelAdd(_ sender: UIButton) {
    }
    
    @IBOutlet weak var SelectBar: UISegmentedControl!
    @IBOutlet weak var FirstPage: UIView!
    @IBOutlet weak var SecondPage: UIView!
    @IBOutlet weak var ThirdPage: UIView!
    @IBOutlet weak var FourthPage: UIView!
}
