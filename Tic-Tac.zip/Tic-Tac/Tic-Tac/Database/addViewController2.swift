//
//  addViewController2.swift
//  Tic-Tac
//
//  Created by mac on 2018/4/1.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import CoreData

class addViewController2: UIViewController{
    @IBOutlet weak var MemoEntry: UITextView!
    var TODO : ToDos?
    override func viewDidLoad() {
        super.viewDidLoad()
        LongTermName.isHidden = true
        LongTermButton.isHidden = true
    }
    
    @IBOutlet weak var LongTermButton: UIButton!
    @IBOutlet weak var LongTermName: UILabel!
    
    @IBOutlet weak var LongTermSwitch: UISwitch!
    
    @IBAction func LongTermSwitchTrigger(_ sender: Any) {
        if LongTermSwitch.isOn{
            LongTermName.isHidden = false
            LongTermButton.isHidden = false
        }else{
            LongTermName.isHidden = true
            LongTermButton.isHidden = true
        }
    }
    @IBOutlet weak var TimePicker: UIDatePicker!
    
    
    
    @IBAction func ConfirmBtn(_ sender: UIButton) {
        
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        
        if (MemoEntry.text! != ""){
            if !LongTermSwitch.isOn{
                let _ = ToDosDAO.addWithPeriod(memo: MemoEntry.text!, period: Int(TimePicker.countDownDuration) )
            }else{
                //刘峻彤：把你的LongTermTODO加在这里
            }
                ToDosDAO.saveChanges()
        }else{
            let alertController:UIAlertController=UIAlertController(title: "You need to choose basic informations!", message: "", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default))
            self.present(alertController, animated: true, completion: nil)
        }
    }
}
