//
//  addViewController.swift
//  Liu Juntong
//
//  Created by Liu Juntong on 2018/3/21.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit
import CoreData

class addViewController: UIViewController{
    @IBOutlet weak var MemoEntry: UITextView!
    @IBOutlet weak var EndTimeLabel: UILabel!
    @IBOutlet weak var BeginTimeLabel: UILabel!
    var TODO : ToDos?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        /*let ids = ToDosDAO.getByID(ID: 1521887283)
        for i in ids{
        print("i:\(i.memo! as String),\(i.beginTime! as Date),\(i.endTime! as Date),\(i.priority as! Int),\(i.id as! Int),\(i.flag )")
        }*/
        
        /*let datees = ToDosDAO.getByEndTime(Time: )
        for d in datees{
            print("d:\(d.memo! as String),\(d.beginTime! as Date),\(d.endTime! as Date),\(d.priority as! Int),\(d.id as! Int),\(d.flag )")
        }*/

    }
    
    func chooseByEndT(time: Date){
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        let datees = ToDosDAO.getByEndTime(Time: time)
        for d in datees{
            print("d:\(d.memo! as String),\(d.beginTime! as Date),\(d.endTime! as Date),\(d.id as! Int),\(d.flag )")
        }
    }
    
    func transTimeS(time: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let convertedDate = dateFormatter.string(from: time)
        return convertedDate
    }
    
    func transTimeST(time: String) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return dateFormatter.date(from: time)!
    }
    
    
    func pickerView(type:UIImagePickerControllerSourceType) {
        let pickerVC = UIImagePickerController()
        pickerVC.view.backgroundColor = UIColor.white
        pickerVC.allowsEditing = true
        pickerVC.sourceType = type
        present(pickerVC, animated: true, completion: nil)
    }
    
    
    
    enum ImageAttachmentMode {
        case `default`  //默认（不改变大小）
        case fitTextLine  //使尺寸适应行高
        case fitTextView  //使尺寸适应textView
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        dismiss(animated: true, completion: nil)
        
    }
    //选中
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        dismiss(animated: true, completion: nil)
        
        if let image = info[UIImagePickerControllerEditedImage] as? UIImage {
            insertPicture(image)
        }
        print("%@",info)
    }
    

    func insertPicture(_ image:UIImage, mode:ImageAttachmentMode = .default){
        //获取textView的所有文本，转成可变的文本
        let mutableStr = NSMutableAttributedString(attributedString: MemoEntry.attributedText)
        
        //创建图片附件
        let imgAttachment = NSTextAttachment(data: nil, ofType: nil)
        var imgAttachmentString: NSAttributedString
        imgAttachment.image = image
        
        //设置图片显示方式
        if mode == .fitTextLine {
            //与文字一样大小
            imgAttachment.bounds = CGRect(x: 0, y: -4, width: MemoEntry.font!.lineHeight,
                                          height: MemoEntry.font!.lineHeight)
        } else if mode == .fitTextView {
            //撑满一行
            let imageWidth = MemoEntry.frame.width - 10
            let imageHeight = image.size.height/image.size.width*imageWidth
            imgAttachment.bounds = CGRect(x: 0, y: 0, width: imageWidth, height: imageHeight)
        }
        
        imgAttachmentString = NSAttributedString(attachment: imgAttachment)
        
        //获得目前光标的位置
        let selectedRange = MemoEntry.selectedRange
        //插入文字
        mutableStr.insert(imgAttachmentString, at: selectedRange.location)
        
        //再次记住新的光标的位置
        let newSelectedRange = NSMakeRange(selectedRange.location+1, 0)
        
        //重新给文本赋值
        MemoEntry.attributedText = mutableStr
        //恢复光标的位置（上面一句代码执行之后，光标会移到最后面）
        MemoEntry.selectedRange = newSelectedRange
        //移动滚动条（确保光标在可视区域内）
        MemoEntry.scrollRangeToVisible(newSelectedRange)
    }
    
    
    
    @IBAction func selectBeginDate(sender: AnyObject) {
        
        let alertController:UIAlertController=UIAlertController(title: "\n\n\n\n\n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        // 初始化 datePicker
        let datePicker = UIDatePicker( )
        // 设置样式，当前设为同时显示日期和时间
        datePicker.datePickerMode = UIDatePickerMode.dateAndTime
        // 设置默认时间
        datePicker.date = NSDate() as Date
        // 响应事件（只要滚轮变化就会触发）
        // datePicker.addTarget(self, action:Selector("datePickerValueChange:"), forControlEvents: UIControlEvents.ValueChanged)
        alertController.addAction(UIAlertAction(title: "确定", style: UIAlertActionStyle.default){
            (alertAction)in
            
            self.BeginTimeLabel.text = self.transTimeS(time: datePicker.date)
            
        })
        alertController.addAction(UIAlertAction(title: "取消", style: UIAlertActionStyle.cancel,handler:nil))
        
        alertController.view.addSubview(datePicker)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func selectEndDate(sender: AnyObject) {
        
        let alertController:UIAlertController=UIAlertController(title: "\n\n\n\n\n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        // 初始化 datePicker
        let datePicker = UIDatePicker( )
        // 设置样式，当前设为同时显示日期和时间
        datePicker.datePickerMode = UIDatePickerMode.dateAndTime
        // 设置默认时间
        datePicker.date = NSDate() as Date
        // 响应事件（只要滚轮变化就会触发）
        // datePicker.addTarget(self, action:Selector("datePickerValueChange:"), forControlEvents: UIControlEvents.ValueChanged)
        alertController.addAction(UIAlertAction(title: "确定", style: UIAlertActionStyle.default){
            (alertAction)in
            self.EndTimeLabel.text = self.transTimeS(time: datePicker.date)
        })
        
        alertController.addAction(UIAlertAction(title: "取消", style: UIAlertActionStyle.cancel,handler:nil))
        alertController.view.addSubview(datePicker)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func GetPhoto(_ sender: UIButton) {
        var sourceType: UIImagePickerControllerSourceType = .photoLibrary
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let alertController = UIAlertController()
            let alert1:UIAlertAction = UIAlertAction.init(title: "打开相册", style: .default, handler: { (action) in
                sourceType = .photoLibrary
                self.pickerView(type: sourceType)
            })
            
            let alert2:UIAlertAction = UIAlertAction.init(title: "打开相机", style:.default, handler: { (action) in
                sourceType = .camera
                
                self.pickerView(type: sourceType)
                
            })

            let alert3:UIAlertAction = UIAlertAction.init(title: "取消", style: .cancel, handler: { (action) in

                print("取消")
                
            })
            alertController.addAction(alert1)
            
            alertController.addAction(alert2)
            
            alertController.addAction(alert3)
            
            self.present(alertController, animated: true, completion: nil)
        
        }
            //如果相机不可用
            
        else{
            let alertController = UIAlertController()

            let alert2:UIAlertAction = UIAlertAction.init(title: "打开相册", style:.default, handler: { (action) in
                sourceType = .photoLibrary
                self.pickerView(type: sourceType)
            })
            
            let alert3:UIAlertAction = UIAlertAction.init(title: "取消", style: .cancel, handler: { (action) in
                print("取消")
            })

           alertController.addAction(alert2)
            
           alertController.addAction(alert3)
            
           self.present(alertController, animated: true, completion: nil)
        }
    }

    
    @IBAction func ConfirmBtn(_ sender: UIButton) {
        
        let dele = (UIApplication.shared.delegate as! AppDelegate)
        let context = dele.persistentContainer.viewContext
        let ToDosDAO = ToDoDAO(context: context)
        
        if (MemoEntry.text! != "") && (BeginTimeLabel.text! != "") && (EndTimeLabel.text! != ""){
        
        if transTimeST(time: BeginTimeLabel.text!) < transTimeST(time: EndTimeLabel.text!){
            let _ = ToDosDAO.addWithTime(memo: MemoEntry.text!, beginTime: transTimeST(time: BeginTimeLabel.text!),endTime: transTimeST(time: EndTimeLabel.text!))
        ToDosDAO.saveChanges()
        }else{
            let alertController:UIAlertController=UIAlertController(title: "You can't choose a end time before begin time!", message: "", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default))
            self.present(alertController, animated: true, completion: nil)
        }
        }else{
            let alertController:UIAlertController=UIAlertController(title: "You need to choose basic informations!", message: "", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
}
