//
//  File.swift
//  Tic-Tac
//
//  Created by mac on 2018/4/18.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit

class TimelineCell: UITableViewCell{
    
    
    @IBAction func Bubble(_ sender: UIButton) {
    }
    
    
}
