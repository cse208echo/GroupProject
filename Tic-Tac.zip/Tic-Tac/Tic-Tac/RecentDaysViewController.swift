//
//  RecentDaysViewController.swift
//  Tic-Tac
//
//  Created by mac on 2018/4/25.
//  Copyright © 2018年 Echo. All rights reserved.
//

import UIKit

class RecentDaysViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Test.insertText("")
    }
    
    @IBOutlet weak var Test: UITextField!
}
